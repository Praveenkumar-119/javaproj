package travel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class MapWindow extends JFrame {
    private static final String API_KEY = "ojCmw35Slz58uHSc7G_5DVhNRknkfPkJB_YhDRF64vs"; // Replace with your actual API key
    private static final String API_URL = "https://maps.googleapis.com/maps/api/directions/json"; // API URL

    public MapWindow() {
        setTitle("Route Finder");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // User interface setup
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());

        JLabel sourceLabel = new JLabel("Source:");
        JTextField sourceField = new JTextField(10);
        JLabel destinationLabel = new JLabel("Destination:");
        JTextField destinationField = new JTextField(10);
        JButton findRouteButton = new JButton("Find Route");

        panel.add(sourceLabel);
        panel.add(sourceField);
        panel.add(destinationLabel);
        panel.add(destinationField);
        panel.add(findRouteButton);
        add(panel, BorderLayout.NORTH);

        JTextArea resultArea = new JTextArea();
        resultArea.setEditable(false);
        add(new JScrollPane(resultArea), BorderLayout.CENTER);

        // Action listener for the button
        findRouteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String source = sourceField.getText().trim();
                String destination = destinationField.getText().trim();

                // Debugging message
                System.out.println("Find Route button clicked with Source: '" + source + "' and Destination: '" + destination + "'");

                if (!source.isEmpty() && !destination.isEmpty()) {
                    try {
                        // First try to get the route from the API
                        String apiRoute = getRouteFromAPI(source, destination);
                        resultArea.setText("API Route:\n" + apiRoute);
                    } catch (Exception ex) {
                        System.out.println("Error fetching route from API: " + ex.getMessage());
                        resultArea.setText("Error fetching route from API. Trying A* algorithm...");

                        // Fall back to the A* algorithm if API fails
                        Map<String, Node> graph = createSampleGraph();
                        List<String> route = AStarAlgorithm.findShortestPath(graph, source, destination);

                        // Check if route is found
                        if (route != null) {
                            resultArea.setText("A* Shortest Route:\n" + String.join(" -> ", route));
                        } else {
                            resultArea.setText("No route found using A* algorithm.");
                        }
                    }
                } else {
                    resultArea.setText("Please enter both source and destination.");
                    System.out.println("Source or destination is empty.");
                }
            }
        });

        setVisible(true);
    }

    // Method to call the API for route calculation
    private String getRouteFromAPI(String source, String destination) throws Exception {
        // Create the URL with the source and destination
        String url = API_URL + "?origin=" + source + "&destination=" + destination + "&key=" + API_KEY;

        // Make an HTTP request to the API
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Accept", "application/json");

        // Read the response
        if (conn.getResponseCode() != 200) {
            throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
        }

        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String output;
        while ((output = br.readLine()) != null) {
            response.append(output);
        }

        conn.disconnect();

        // Process the response to extract the route information
        return parseRouteFromJson(response.toString());
    }

    // Parse the JSON response to extract route information
    private String parseRouteFromJson(String jsonResponse) {
        JSONObject jsonObject = new JSONObject(jsonResponse);
        JSONArray routes = jsonObject.getJSONArray("routes");
        if (routes.length() > 0) {
            // Assume we want the first route
            JSONObject route = routes.getJSONObject(0);
            JSONArray legs = route.getJSONArray("legs");
            JSONObject leg = legs.getJSONObject(0);
            StringBuilder routeInstructions = new StringBuilder();
            
            JSONArray steps = leg.getJSONArray("steps");
            for (int i = 0; i < steps.length(); i++) {
                JSONObject step = steps.getJSONObject(i);
                String instruction = step.getString("html_instructions");
                routeInstructions.append(instruction).append("\n");
            }
            
            return routeInstructions.toString();
        } else {
            return "No route found.";
        }
    }

    // Sample graph creation method (replace with actual data)
    private Map<String, Node> createSampleGraph() {
        Map<String, Node> graph = new HashMap<>();
        // Add nodes and their neighbors with distances (dummy data)
        graph.put("A", new Node("A", Map.of("B", 5, "C", 10)));
        graph.put("B", new Node("B", Map.of("A", 5, "D", 3)));
        graph.put("C", new Node("C", Map.of("A", 10, "D", 7)));
        graph.put("D", new Node("D", Map.of("B", 3, "C", 7, "E", 1)));
        graph.put("E", new Node("E", Map.of("D", 1)));

        System.out.println("Sample graph created with nodes: " + graph.keySet());
        return graph;
    }

    // Inner Node class
    static class Node {
        String name;
        Map<String, Integer> neighbors;

        Node(String name, Map<String, Integer> neighbors) {
            this.name = name;
            this.neighbors = neighbors;
        }
    }

    // Inner AStarAlgorithm class
    static class AStarAlgorithm {
        public static List<String> findShortestPath(Map<String, Node> graph, String start, String goal) {
            Map<String, Integer> gScore = new HashMap<>();
            Map<String, Integer> fScore = new HashMap<>();
            Map<String, String> cameFrom = new HashMap<>();
            Set<String> closedSet = new HashSet<>();
            PriorityQueue<String> openSet = new PriorityQueue<>(Comparator.comparingInt(fScore::getOrDefault));

            gScore.put(start, 0);
            fScore.put(start, heuristic(start, goal));
            openSet.add(start);

            while (!openSet.isEmpty()) {
                String current = openSet.poll();
                if (current.equals(goal)) {
                    return reconstructPath(cameFrom, current);
                }

                closedSet.add(current);

                for (Map.Entry<String, Integer> neighborEntry : graph.get(current).neighbors.entrySet()) {
                    String neighbor = neighborEntry.getKey();
                    int tentativeGScore = gScore.getOrDefault(current, Integer.MAX_VALUE) + neighborEntry.getValue();

                    if (closedSet.contains(neighbor))
                        continue;
                    if (tentativeGScore < gScore.getOrDefault(neighbor, Integer.MAX_VALUE)) {
                        cameFrom.put(neighbor, current);
                        gScore.put(neighbor, tentativeGScore);
                        fScore.put(neighbor, tentativeGScore + heuristic(neighbor, goal));
                        if (!openSet.contains(neighbor)) {
                            openSet.add(neighbor);
                        }
                    }
                }
            }
            return null; // No path found
        }

        private static List<String> reconstructPath(Map<String, String> cameFrom, String current) {
            List<String> path = new ArrayList<>();
            while (current != null) {
                path.add(current);
                current = cameFrom.get(current);
            }
            Collections.reverse(path);
            return path;
        }

        private static int heuristic(String node, String goal) {
            return 0; // Simple heuristic for demonstration
        }
    }
}
