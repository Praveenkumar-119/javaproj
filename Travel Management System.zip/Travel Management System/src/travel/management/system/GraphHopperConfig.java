package travel.management.system;

import io.dropwizard.Configuration;
import com.graphhopper.http.GraphHopperConfig;

public class GraphHopperConfig extends Configuration {
    private GraphHopperConfig graphhopper;

    public GraphHopperConfig getGraphhopper() {
        return graphhopper;
    }

    public void setGraphhopper(GraphHopperConfig graphhopper) {
        this.graphhopper = graphhopper;
    }
}