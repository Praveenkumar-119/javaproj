package travel.management.system;

import io.dropwizard.Application;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import com.graphhopper.http.GraphHopperManaged;

public class GraphHopperRunner extends Application<GraphHopperConfig> {
    public static void main(String[] args) throws Exception {
        new GraphHopperRunner().run(args);
    }

    @Override
    public void initialize(Bootstrap<GraphHopperConfig> bootstrap) {
        // Initialization logic if needed
    }

    @Override
    public void run(GraphHopperConfig configuration, Environment environment) {
        GraphHopperManaged graphHopper = new GraphHopperManaged(configuration.getGraphhopper());
        environment.lifecycle().manage(graphHopper);
    }
}
