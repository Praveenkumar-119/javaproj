package travel.management.system;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;

class Node implements Comparable<Node> {
    public String name;
    public double gCost; // Cost from start to this node
    public double hCost; // Heuristic cost from this node to goal
    public Node parent;
    public Map<Node, Double> neighbors; // Neighbor nodes and their distances

    public Node(String name) {
        this.name = name;
        this.neighbors = new HashMap<>();
    }

    public double fCost() {
        return gCost + hCost;
    }

    @Override
    public int compareTo(Node other) {
        return Double.compare(this.fCost(), other.fCost());
    }
}

public class AStarAlgorithm {
    // A* algorithm to find the shortest path
    public static List<String> findShortestPath(Node start, Node goal) {
        PriorityQueue<Node> openSet = new PriorityQueue<>();
        Set<Node> closedSet = new HashSet<>();
        
        start.gCost = 0;
        start.hCost = heuristic(start, goal);
        openSet.add(start);
        
        while (!openSet.isEmpty()) {
            Node current = openSet.poll();
            
            if (current.equals(goal)) {
                // Reconstruct the path
                return reconstructPath(current);
            }
            
            closedSet.add(current);
            
            for (Map.Entry<Node, Double> entry : current.neighbors.entrySet()) {
                Node neighbor = entry.getKey();
                double tentativeGCost = current.gCost + entry.getValue();
                
                if (closedSet.contains(neighbor)) continue;
                
                if (tentativeGCost < neighbor.gCost) {
                    neighbor.gCost = tentativeGCost;
                    neighbor.hCost = heuristic(neighbor, goal);
                    neighbor.parent = current;
                    
                    if (!openSet.contains(neighbor)) {
                        openSet.add(neighbor);
                    }
                }
            }
        }
        return null; // No path found
    }

    // Heuristic function (straight-line distance)
    private static double heuristic(Node node, Node goal) {
        // Replace this with your own heuristic calculation, e.g., distance based on coordinates
        return 0; // Placeholder
    }

    // Reconstruct the path from the goal node
    private static List<String> reconstructPath(Node current) {
        List<String> path = new ArrayList<>();
        while (current != null) {
            path.add(current.name);
            current = current.parent;
        }
        Collections.reverse(path);
        return path;
    }
}
